getwd()
setwd("C:\\Users\\user\\Desktop\\IT24102511")
getwd()

#Question 01
#part 1 
#Binomial Distribution
#Here, random variable x has binomial distribution with n=50 and p=0.85

#part 2
1 - pbinom(46,50,0.85,lower.tail = TRUE)
#Or else following command can also used by keeping argument "lower.tail" as "FALSE"
pbinom(46,50,0.85,lower.tail = FALSE)

#Question2
#part 1
#Number of customer calls in one hour

#part 2
#Poisson Distribution
#Here, random variable X has poisson distribution with lambda=12

#part3
#It asks to find P(X=15) Following command gives the density
dpois(15,12)
