#Q1
a<-10
b<-3

#Q2
a+b
a%/%b
a%%b
a^b

#Q3
#part(a)
isTRUE(a<b)
#part(b)
isTRUE(b==3)
#part(c)
isTRUE(a>5 | b<2)

#Q4
scores <- c(85,90,78,92,NA,88)
#part(a)
class(scores)
#part(b)
mean(scores, na.rm = TRUE)
#part(c)
scores > 85

#Q5
names <- c("Alice","Bob", "Charlie", "Diana", "Even", "Fiona")
passed <- scores >= 80

#Q6
results <- data.frame(Name = names, Score = scores, Passed = passed)

#Q7
str(results)
print(results)

#Q8
results$Score[results$Score > 85]
